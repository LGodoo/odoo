# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import hashlib
import base64
from werkzeug import urls

from odoo import api, fields, models, _
from odoo.addons.payment.models.payment_acquirer import ValidationError
from odoo.addons.payment_jcc_test.helpers import constants
from odoo.addons.payment_jcc_test.controllers.main import jccController
from odoo.tools.float_utils import float_compare

import logging

_logger = logging.getLogger(__name__)

CURRENCY_CODES = {
    'EUR': '978',
    'USD': '840',
    'CHF': '756',
    'GBP': '826',
    'RUB': '643'
}

class PaymentAcquirerjcc(models.Model):
    _inherit = 'payment.acquirer'

    provider = fields.Selection(selection_add=[('jcc', 'JCC')])
    MerchantID = fields.Char(string='MerchantID', required_if_provider='jcc', groups='base.group_user')
    AcquirerID = fields.Char(string='AcquirerID', required_if_provider='jcc', groups='base.group_user')

    def _get_jcc_urls(self, environment):
        """ JCC URLs"""
        if environment == 'prod':
            return {'jcc_form_url': 'https://jccpg.jccsecure.com/EcomPayment/RedirectAuthLink'}
        else:
            if environment == 'test':
                return {'jcc_form_url': 'https://tjccpg.jccsecure.com/EcomPayment/RedirectAuthLink'}

    def _jcc_generate_sign(self, inout, values):
        """ Generate the shasign for incoming or outgoing communications.
        :param self: the self browse record. It should have a shakey in shakey out
        :param string inout: 'in' (odoo contacting jcc) or 'out' (jcc
                             contacting odoo).
        :param dict values: transaction values

        :return string: shasign
        """
        if inout not in ('in', 'out'):
            raise Exception("Type must be 'in' or 'out'")

        if inout == 'in':
            keys = "Password|MerchantID|AcquirerID|OrderID|PurchaseAmt|PurchaseCurrency||||||||".split('|')
            sign = ''.join('%s|' % (values.get(k) or '') for k in keys)

        else:
            keys = "Password|MerchantID|AcquirerID|OrderID|||||".split('|')
            sign = ''.join('%s|' % (values.get(k) or '') for k in keys)

        shasignnoencoding = hashlib.sha1(sign.encode('utf-8')).hexdigest()
        shasign = base64.b64encode(shasignnoencoding.encode())

        return shasign



    @api.multi
    def jcc_form_generate_values(self, values):
        self.ensure_one()
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        jcc_values = dict(values)
        temp_jcc_values = {
            'Version': '1.0.0',
            'MerID': self.MerchantID,
            'AcqID': self.AcquirerID,
            'MerRespURL': urls.url_join(base_url, jccController._return_url),
            #'MerRespURL': 'https://stackoverflow.com/questions/37482854/how-to-create-a-sha1-hash-in-python',
            'PurchaseAmt': str(values['amount']).zfill(13).replace('.',''),
            'PurchaseCurrency':CURRENCY_CODES.get(values['currency'].name),
            'PurchaseCurrencyExponent':'2',
            'OrderID': values['reference'],
            'Password': '1234',
            'CaptureFlag': 'A',
            #'Signature':'sU3MeEKlPx7HpiHnfBBt++goN3k=',
            'Signature': 'shasing',
            'SignatureMethod':'SHA1',

                         }

        jcc_values.update(temp_jcc_values)
        jcc_values['Signature'] = self._jcc_generate_sign('in', jcc_values)
        error_msg = 'TEST'
        _logger.info(error_msg)
        return jcc_values

    @api.multi
    def jcc_get_form_action_url(self):
        #self.ensure_one()
        return self._get_jcc_urls(self.environment)['jcc_form_url']


class PaymentTransactionjcc(models.Model):
    _inherit = 'payment.transaction'

    @api.model
    def _jcc_form_get_tx_from_data(self, data):
        """ Given a data dict coming from jcc, verify it and find the related
        transaction record. """
        reference = data.get('reference')
        MerID = self.MerchantID
        AcqID = self.AcquirerID
        OrderID = data.get('OrderID')
        ResponseCode = data.get('ResponseCode')
        ReasonCode = data.get('ReasonCode')
        ReasonCodeDesc = data.get('ReasonCodeDesc')
        ReferenceNo = data.get('ReferenceNo')
        PaddedCardNo = data.get('PaddedCardNo')
        ResponseSignature = data.get('ResponseSignature')
        shasign = data.get('Signature')

        if not reference or not OrderID or not shasign or not MerID or not AcqID:
            raise ValidationError(_('jcc: received data with missing reference (%s) or OrderID(%s) or shasing (%s)') % (reference, OrderID, shasign))

        transaction = self.search([('reference', '=', reference)])

        if not transaction:
            error_msg = (_('jcc: received data for reference %s; no order found') % (reference))
            raise ValidationError(error_msg)
        elif len(transaction) > 1:
            error_msg = (_('jcc: received data for reference %s; multiple orders found') % (reference))
            raise ValidationError(error_msg)

        #verify shasign
        shasign_check = transaction.acquirer_id._jcc_generate_sign('out', data)
        if shasign_check.upper() != shasign.upper():
            raise ValidationError(_('jcc: invalid shasign, received %s, computed %s, for data %s') % (shasign, shasign_check, data))
        return transaction

    @api.multi
    def _jcc_form_get_invalid_parameters(self, data):
        invalid_parameters = []

        if self.acquirer_reference and data.get('ReferenceNo') != self.acquirer_reference:
            invalid_parameters.append(
               ('Transaction Id', data.get('ReferenceNo'), self.acquirer_reference))
        #check what is purchased
        if float_compare(float(data.get('amount', '0.0')), self.amount, 2) != 0:
            invalid_parameters.append(
                ('Amount', data.get('amount'), '%.2f' % self.amount))

        return invalid_parameters

    @api.multi
    def _jcc_form_validate(self, data):
        ResponseCode = data.get('ResponseCode')
        result = self.write({
            'acquirer_reference': data.get('ReferenceNo'),
            'date': fields.Datetime.now(),
        })
        if ResponseCode == '1':
            self._set_transaction_done()
            error_msg = 'done'
            _logger.info(error_msg)
        #if ResponseCode =='2':
            #error_msg = 'declined'
            #_logger.info(error_msg)
            #if ResponseCode == '0':
             #   error_msg = 'token/hash deactivation'
            #    _logger.info(error_msg)
        else:
            auth_result = data.get('ReasonCode')
            auth_message = ''
            if auth_result in constants.JCC_AUTH_RESULT:
                auth_message = constants.JCC_AUTH_RESULT[auth_result]

            error_msg = 'JCC payment error, message %s, code %s' % (auth_message, auth_result)
            _logger.info(error_msg)

        return result
